package com.example.webapp.repositery;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.webapp.model.Employee;

public interface EmployeeRepositery extends JpaRepository<Employee, Long> {
  

}
