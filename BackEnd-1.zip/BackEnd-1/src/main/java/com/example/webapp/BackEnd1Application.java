package com.example.webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEnd1Application {

	public static void main(String[] args) {
		SpringApplication.run(BackEnd1Application.class, args);
	}

}
